import os.path
from pathlib import Path

import pandas as pd

import openpyxl as df

from scr.lista_antivirus import (lista_antivirus, criador_lista)
from scr.tabela_files import tabela_files

dir_entrada = Path("../VirusTotal")

###########################################################

criador_lista(dir_entrada)
list_antivirus = lista_antivirus()
resultado = dict()
resultado_antivirus = dict()
ranking = list()


###########################################################
# cria um dicionario de file por antivirus_submetidos
if not Path.joinpath(Path.cwd(), "Lista_antivirus").is_file(): criador_lista(dir_entrada)

#[resultado.update({file: tabela_files(file)}) for file in dir_entrada.iterdir()]

# Cria um dicionario de antivirus por lista de resultados
#[resultado_antivirus.update({antivirus: [resultado.get(file).get(antivirus) for file in dir_entrada.iterdir()] }) for antivirus in list_antivirus]
# Converta de resultados para Detectados, n_detectados e omissos

resultado={}
parcial = list()
for file in dir_entrada.iterdir():

    qq = tabela_files(file)
    resultado.update({file.name: dict(qq)})
#print(resultado.get("VirusShare_0a2dae30ff0a3581078529f8a1b9c71f.json").get("TotalDefense"))


for antivirus in list_antivirus:
    parcial = []
    for file in dir_entrada.iterdir():
        parcial.append(resultado.get(file.name).get(antivirus))
    resultado_antivirus.update({str(antivirus): parcial})



for antivirus in resultado_antivirus:
    detectado = 0
    n_detectado  = 0
    omisso = 0
    for line in resultado_antivirus[antivirus]:
        if line == True: detectado +=1
        elif line == False: n_detectado +=1
        elif line == None: omisso +=1
    ranking.append(list(map(lambda x: round(x/len(resultado)*100,2), [detectado, n_detectado,omisso])))

print(len(resultado))
df = pd.DataFrame(ranking,index=list_antivirus, columns=['Detectado','Não Detectado', "Omisso"])
df.sort_values(by = 'Detectado',ascending=False, inplace=True)

df.to_excel(f"{dir_entrada.name}_Ranking.xlsx", sheet_name="Resultados {dir_entrada.name}")

###############################################################
