from pathlib import Path
import json
def lista_antivirus():

    with open("Lista_antivirus" ,'r') as lista:
        return [line.strip('\n') for line in lista.readlines()]



def criador_lista(dir_entrada):
    """
    Script criado para realizar a criação da lista de antivirus que sera analisada pelo script Ranking_antivirus.py
    :param dir_entrada: diretorio de um repositorio virustotal para que possamos extrair os antivirus relacionados
    :return: lista de antivirus
    """
    data = dict()
    lista = list()
    print("Criando lista a ser analisada")
    for file in dir_entrada.iterdir():
        with open( file, 'r') as file_read_json:
            data = json.load(file_read_json)
        [lista.append(antivirus) for antivirus in data['scans'].keys() if antivirus not in lista]
        print(file)

    with open("Lista_antivirus", 'w') as correta:
        [correta.write(isso+"\n") for isso in lista]


if __name__ == "__main__":
    print(lista_antivirus())

