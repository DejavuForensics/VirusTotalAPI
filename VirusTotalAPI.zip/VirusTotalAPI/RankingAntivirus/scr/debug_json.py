import json

def debug_json(file):
    with open(file, 'r') as file_json:
        data = json.dumps(file_json.read(), indent=4)


if __name__ == "__main__":
    debug_json("/media/liosvaldo/SANTIAGO/Grupo_de_pesquisa/Malignos_pacote/Apk/VirusShare_0001b6590ac6ca03f92aeddd27ec69ea.txt")
