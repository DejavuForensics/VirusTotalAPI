from scr.lista_antivirus import lista_antivirus
import json
from pathlib import Path
"""

Script feito para entrar um file .json e retornar apenas o filtrado do seu nome é de seu resultado detectado

"""
tabela = dict()
def tabela_files(file):
    list_antivirus = lista_antivirus()
    with open(file,'r') as file_read:
        data = json.load(file_read)
    for antivirus in list_antivirus:
        try:
            tabela[antivirus] = data['scans'][antivirus]['detected']
        except KeyError:

            tabela[antivirus] = None

    return tabela

if __name__ == "__main__":
    a =tabela_files("/home/liosvaldo/Documentos/projetos/dejavu/intro/Script/Ranking_Antivirus/Intel80386_jsons/VirusShare_0a7c24817a48c4b518ca42ec97382cef.json")
    print(a)
