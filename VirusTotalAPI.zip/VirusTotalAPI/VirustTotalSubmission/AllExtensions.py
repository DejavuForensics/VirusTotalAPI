import os

# Caminho para a pasta onde estão os arquivos já descompactados
output_dir = "/home/kali/Downloads/VirusTotalAPI/Malware"

# Lista para armazenar todas as extensões encontradas
all_extensions = []

def collect_extensions(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            _, ext = os.path.splitext(file)
            if ext:  # Só considera se tiver extensão
                all_extensions.append(ext.lower())  # Guarda em minúsculo para evitar duplicatas

# Executa a coleta
collect_extensions(output_dir)

# Remove duplicatas e ordena
unique_extensions = sorted(set(all_extensions))

# Imprime a lista final
print("\n=== EXTENSÕES ÚNICAS ENCONTRADAS EM output_dir ===")
for ext in unique_extensions:
    print(ext)

print(f"\nTotal único encontrado: {len(unique_extensions)}")
