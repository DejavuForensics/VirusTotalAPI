import os

# Caminho base onde estão os arquivos .pass
base_dir = "/home/kali/Downloads/theZoo-master/malware/Binaries/"

# Lista para armazenar todas as strings encontradas
all_strings = []

def collect_strings_from_pass_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".pass"):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        lines = f.readlines()
                        for line in lines:
                            clean_line = line.strip()
                            if clean_line:
                                all_strings.append(clean_line)
                    print(f"Coletado de: {file_path}")
                except Exception as e:
                    print(f"Erro ao ler {file_path}: {e}")

# Chamada principal
collect_strings_from_pass_files(base_dir)

# Remove duplicatas usando set e ordena o resultado
unique_strings = sorted(set(all_strings))

# Imprime a lista única final
print("\n=== STRINGS ÚNICAS COLETADAS ===")
for s in unique_strings:
    print(s)

print(f"\nTotal único encontrado: {len(unique_strings)}")
